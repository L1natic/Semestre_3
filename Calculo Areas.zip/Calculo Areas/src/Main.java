import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        String figura;
        Calculo cuadrado= new Calculo(6,"Cuadrado");
        Calculo rectangulo= new Calculo(6,5,"Rectangulo");
        Scanner sc= new Scanner(System.in);
        BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        //Ingreso de datos
        System.out.println("Ingrese su figura(en minusculas): ");
        figura=sc.nextLine();


    }
}