public class Calculo {
    int longitud;
    int altura;
    String figura;

    public Calculo(int longitud, int altura, String figura){

    }
    public Calculo(int longitud,String figura){

    }

    public int Area(int longitud,int altura, String figura){
        int area=0;
        if(figura=="cuadrado"){
            area=longitud*longitud;
        } else if (figura=="rectangulo") {
            area=longitud*altura;
        }
        return area;
    }
}
