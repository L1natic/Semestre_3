import javax.swing.*;

public class Empleado {
    String nombre;
    String apellido;
    double salario;

    public Empleado(String nombre, String apellido, double salario){
        this.nombre=nombre;
        this.apellido=apellido;
        this.salario=salario;
    }
    public Empleado(){

    }
    public void ingreso_datos(){
        this.nombre= JOptionPane.showInputDialog("Ingrese su nombre: ");
        this.apellido=JOptionPane.showInputDialog("Ingrese su apellido: ");
        this.salario=Integer.parseInt(JOptionPane.showInputDialog("Ingrese su salario mensual: "));
        if(this.salario<0){
            this.salario=0;
        }
    }
    public void imprimir_datos_iniciales(){
        System.out.println("Nombre: " + this.nombre +" " + this.apellido);
        System.out.println("Salario anual: " + (this.salario*12));
    }

    public void imprimir_datos_finales(){
        this.salario=this.salario+(this.salario*0.10);
        System.out.println("Nombre: " + this.nombre +" " + this.apellido);
        System.out.println("Salario anual con aumento: " + (this.salario*12));
    }
}
