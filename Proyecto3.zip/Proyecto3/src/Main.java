import javax.swing.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) throws IOException {
/**Creaciòn de objetos*/
Proveedor vendor1 = new Proveedor();
Proveedor vendor2 = new Proveedor(12345678,"TEMU");
Proveedor vendor3 = new Proveedor(1234452,"MUTE","Sur");
        Scanner sc= new Scanner(System.in);
        BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        /**Instanciaciòn de clase*/
        vendor1.razon_social="Tommy";
        /**Lectura de variables*/
        //1ra forma de lectura/
        System.out.print("RUC del proveedor: ");
        vendor1.RUC=br.read();


        /*2da forma de lectura/
        //No debemos trabajar con cajas de dialogos y terminal a la vez

        vendor1.direccion=JOptionPane.showInputDialog("Direcciòn");
        JOptionPane.showMessageDialog(null,"Direcciòn proveedor: " + vendor1.direccion);

        */
        /**3ra forma de lectura*/
        System.out.println("Razon social del proveedor: ");
        vendor3.razon_social=sc.nextLine();

        /**Despliegue de valores*/
        vendor1.detalle();
        System.out.println();
        vendor2.detalle();
        System.out.println();
        vendor3.detalle();
    }
}