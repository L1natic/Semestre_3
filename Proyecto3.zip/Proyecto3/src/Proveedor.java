import java.beans.PropertyEditor;

public class Proveedor {
    int RUC;
    String razon_social;
    String direccion="Norte";

    public Proveedor(){
    }
    public Proveedor(int RUC, String razon_social){
        this.RUC=RUC;
        this.razon_social=razon_social;
    }
    public Proveedor(int RUC, String razon_social, String direccion){
        this.RUC=RUC;
        this.razon_social=razon_social;
        this.direccion=direccion;
    }
    public void detalle(){
        System.out.println("El RUC: " + RUC);
        System.out.println("La razòn social: " + razon_social);
        System.out.println("La direcciòn: " + direccion);
    }

}
