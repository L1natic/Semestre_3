public class calculos {
    int base;
    int altura;
    int num_lados;
    float area_final;


    public calculos(int base){
        this.base=base;
    }
    public calculos(int base, int altura){
        this.base=base;
        this.altura=altura;
    }
    public calculos(int base, int altura, int num_lados){
        this.base=base;
        this.num_lados=num_lados;
        this.altura=altura;
    }
    public float area(){
        if(num_lados==4){
            if(base==altura || altura==0){
                area_final=base*base;
            }else{
                area_final=base*altura;
            }
        } else if (num_lados==3) {
            area_final= (float) (base * altura) /2;
        }
        return area_final;
    }
    public void Detalles(){
        System.out.println("Base de la figura             : " + this.base);
        if((altura != 0) && (altura != base)){
            System.out.println("Altura de la figura           : " + this.altura);
        }
        System.out.println("Cantidad de lados de la figura: " + this.num_lados);
        System.out.println("Area de la figura             : " + this.area_final);
    }
}
