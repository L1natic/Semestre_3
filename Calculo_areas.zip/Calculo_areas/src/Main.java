import javax.swing.*;

void main() {


    calculos figura1 = new calculos(3);
    calculos figura2 = new calculos(5,7);
    calculos figura3 = new calculos(7,6,4);

    Scanner sc= new Scanner(System.in);
    BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
    /**Ingreso de datos*/
    /**Metodo 1(Mi favorito pero mas impractico)*/

    while (!(3 == figura1.num_lados || figura1.num_lados == 4)) {
        figura1.num_lados = Integer.parseInt(JOptionPane.showInputDialog("Cantidad de lados de la figura 1:"));
        if(!(3 == figura1.num_lados || figura1.num_lados == 4)){
            JOptionPane.showMessageDialog(null,"Ingrese un valor de 3 o 4");
        }
    }

    figura1.base = Integer.parseInt(JOptionPane.showInputDialog("Tamaño de base de figura 1:"));
    //JOptionPane.showMessageDialog(null,"Ancho de la base: "+ figura1.base);
    figura1.altura =Integer.parseInt(JOptionPane.showInputDialog("Tamaño de altura de figura 1:"));
    //JOptionPane.showMessageDialog(null,"Altura: "+ figura1.altura);
    /**Calculo de areas*/
    figura1.area_final=figura1.area();
    figura2.area_final=figura2.area();
    figura3.area_final=figura3.area();

    /**Impresion de datos*/
    figura1.Detalles();
    System.out.println();
    figura2.Detalles();
    System.out.println();
    figura3.Detalles();
}
